function [SD_Yoshi]=getSDell(Lc,Wc,M0);
% Calculates a stress drop value for an ellipse using the
% elliptical integral formulation in appendix A of Kaneko
% and shearer 2014.
% assuming consistent units, M0=Nm; Lc, Wc in meters
% NOTE!!! This is set up for an ellipse with SEMI-MAJOR
% axis of L_c  (and semi-minor =Wc), so the total ellipse is
% 2L_c long.   This is what works best to replicate the true
% area averaged stress drop values in Yoshi's models.
a=Lc; b=Wc;
m=(1-b^2/a^2)^(1/2);
[K,E] = ellipke(m);
denom=3*E+(1/m^2)*(E - (b^2/a^2)*K);
C1=4/denom;
S=pi*a*b;
SD_Yoshi=M0/(C1*S*b);

end

