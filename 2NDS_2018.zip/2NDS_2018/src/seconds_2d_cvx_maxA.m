function [xopt,L_c,W_c,vx,vy,tauc]=seconds_2d_cvx_maxA(Ain,bin,chisq,IPROB);
% implement the second moments inversion in cvx toolbox
% THIS CODE CAN DO 5 PROBLEMS BASED ON the SWITCH IPROBLEM =
% IPROB=1,  MAXIMUM AREA,     minimize(det_inv(Area))
% IPROB=2,  MINIMUM Lc,       minimize(lambda_max(Area))
% IPROB=3,  MAXIMIZE Wc       maximize(lambda_min(Area))
% IPROB=4,  MINIMIZE Lc+Wc    minimize(lambda_sum_largest(Area,2))
% IPROB=5,  MAXIMIZE Lc+Wc    maximize(lambda_sum_largest(Area,2))
% IPROB=6,  MAXIMIZE Lc       maximize(lambda_max
% this version specifies a maximum misfit level chisq that is
% used in the Schur complement LMI (MZJ 2001, eq 23).
% This could be the optimal value from a prior call of seconds_2d_cvx
% Or it could be a larger value corresponding to a particular 
% chi-square value and hence confidence level.

fact=10;  %scaling to deal with numerical precision for short ruptures
A=Ain*fact; b=bin*fact;  %sometimes need this for precision;  cvx_precision doesn't do it.
c=chisq*fact*fact;
Nmeas=length(b);

cvx_begin
 %cvx_precision best
 n=6;
 variables tt xt yt xx xy yy
 expression Xschur(Nmeas+1,Nmeas+1);
 expression Area(2,2);
 expression Xposvolume(3,3);
 Xschur(1,1)=c;
 x=[tt, xt, yt, xx,xy,yy]'
 Xposvolume=[tt,xt,yt; xt, xx, xy; yt,xy,yy];
 Area=[xx,xy; xy, yy];
 %keyboard
 
 for ii=1:length(b)
   %keyboard
   Xschur(1+ii,1+ii)=1;
   Xschur(1,1+ii)=A(ii,1:6)*x-b(ii);
   Xschur(1+ii,1)=A(ii,1:6)*x-b(ii);
 end
 
 % BEST FIT
 %minimize( norm(A*x-b,2) )
 switch IPROB
    case 1
      % MAXIMUM AREA
      minimize(det_inv(Area))
    case 2
      % MINIMUM Lc
      minimize(lambda_max(Area))
    case 3
      %MAXIMIZE Wc
      maximize(lambda_min(Area))
     case 4
       %MINIMIZE Lc+Wc
        minimize(lambda_sum_largest(Area,2))
     case 5
       %maximize Lc+Wc
       maximize(lambda_sum_largest(Area,2))
     case 6
       %sadly doesn't work
       %maximize(det_inv(Area))
       %minimize Lc
       minimize(lambda_max(Area))
     case 7
       %minimize(lambda_min(Area))
 end
  subject to
   Xposvolume==semidefinite(3);
   Xschur==semidefinite(Nmeas+1);
cvx_end

%make output
xopt=x
X=[xopt(4), xopt(5);
   xopt(5),xopt(6);];
[U,S,V]=svd(X);
L_c=2*sqrt(S(1,1));
W_c=2*sqrt(S(2,2));
vx=xopt(2)/xopt(1);
vy=xopt(3)/xopt(1);
tauc=2*sqrt(xopt(1)); 
