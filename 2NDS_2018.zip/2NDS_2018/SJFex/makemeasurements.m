function [t2,DONE,STF,GFsv,dhatsv,datasv,Tsv,T1sv,epsv,epldsv,tpldsv,t0,t1,PhaseSv]=makemeasurements(velEGFa,velMSa,niter,npMS,npEGF,dtsva,stasm,compm,pickt2);
ns=size(velEGFa,1);
% Will save the measurements in MEASUREMENTS.MAT
newmeas=menu('MEASUREMENTS','Start New','Load from MEASUREMENTS.mat');
%
% INitialize variables  CHANGE THIS AFTER FIRST TIME TO AVOID OVERWRITE
%firsttime=1;
if(newmeas==1)
  DONE=zeros(ns,1); logical(DONE);
  Npts=2048;
  t2(1:ns)=99999; t1(1:ns)=0; t0=t1; dtsv(1:ns)=0;
  %partials=zeros(ns,10);
  %nmeas=0;
  %rsv=zeros(ns,3);
  datasv=zeros(ns,Npts);
  dtsv=zeros(ns,1);
  dhatsv=zeros(ns,Npts);
  GFsv=zeros(ns,Npts);
  STF=zeros(ns,Npts);
  STF_sm=zeros(size(STF));
  %slat=zeros(ns,1); slons=zeros(ns,1);
  Tsv=zeros(ns,1); 
  T1sv=zeros(ns,1);
  epsv=zeros(ns,1);
  epldsv=zeros(ns,Npts);
  tpldsv=zeros(ns,Npts);
elseif(newmeas==2)
  load MEASUREMENTS.mat
end  
dofilt=logical(1);   
dtsv=dtsva;
%keyboard
whos DONE

for i=1:ns
 if(npEGF(i)>=100 && npMS(i)>=100)
  velMS=velMSa(i,1:npMS(i)); velMS=velMS';
  velEGF=velEGFa(i,1:npEGF(i)); velEGF=velEGF';
  tms=[1:npMS(i)]*dtsva(i);
  tegf=[1:npEGF(i)]*dtsva(i);
  doi=1;
 else
  doi=0;
 end
 while(doi);
    %whos tms tegf velMS velEGF
    figure
    plot(tms-tms(1),velMS/max(velMS));
    hold on
    title([stasm(i,:),'-',compm(i,:)])
    plot(tegf-tegf(1),velEGF/max(velEGF),'r');
    legend('Mainshock','EGF'); xlabel('Time (s)');
    if(DONE(i)==1)
      ipick(i)=menu('THIS ONE IS DONE, REDO?','Yes','No');
    else
      ipick(i)=menu('NOT DONE, Go Ahead w/Decon?','Yes','No');
    end
    close
    if(ipick(i) == 1) 
    
    
% NOW GET DATA VECTOR AND T1    
     figure
     plot(velMS)
     title(stasm(i,:))
     disp('Pick range to Zoom in to')
     [x y] = ginput(1);
     tt1b=round(x);
     [x y]=ginput(1);
     tt2b=round(x);
     plot(velMS(tt1b:tt2b))
     title([stasm(i,:),' ',compm(i,:)])
     disp('Pick range to invert')
     [x y] = ginput(1);
     [x2 y2]=ginput(1);
     tt2b=tt1b+round(x2);
     tt1b=tt1b+round(x);
     if(tt2b-tt1b>=Npts)
      data=velMS(tt1b:tt1b+Npts-1);
     else
      data=velMS(tt1b:tt2b); 
     end
     clf
     plot(data)
     disp('Pick P or S-wave arrival time');
     [x y] = ginput(1);
     T1=round(x)-3;
     np=length(data);
     zz=taper(np,.1);
     data=data.*zz;     %TAPER P-WAVE
     data(np+1:Npts)=0;
     datasv(i,1:Npts)=data';
     close

%  NOW GET GF 
     figure
     plot(velEGF)
     title(stasm(i,:))
     disp('Pick range to Zoom')
     [x y] = ginput(1);
     tt1b=round(x);
     [x y]=ginput(1);
     tt2b=round(x);
     plot(velEGF(tt1b:tt2b))
     title([stasm(i,:),' ',compm(i,:)])
     disp('Pick P or S wave arrival time')
     [x y] = ginput(1);
     close
     tt1b=round(x)+tt1b; 
     %np comes from Mainshock
     %np
     %keyboard
     np=np-T1;
     tt2b=tt1b+np-1;
     GF=velEGF(tt1b:tt2b);
     zz=taper(np,.1);
     zz(1:np/2)=1;
     %GF=GF.*zz';   % TAPER GF    !!!!! DON"T TAPER GF BECAUSE IT STARTS at 
%				    %ARRIVAL TIME?
     GF(np+1:Npts)=0;
     GFsv(i,1:Npts)=GF';
     
     
% NOW GET RSTF
     [f,dhat,T,eps,tpld,epld]=pld(data,GF,T1,niter);
     [t2(i),t1(i),t0(i)]=findt2(f,pickt2);
     dt=dtsv(i);
     t2(i)=t2(i)*dt*dt;
     STF(i,1:Npts)=f';
     dhatsv(i,1:Npts)=dhat';
     Tsv(i)=(T-T1)*dt;
     T1sv(i)=T1*dt;
     epsv(i)=eps;
     npld=length(tpld);
     epldsv(i,1:npld)=epld(1:npld);
     tpldsv(i,1:npld)=tpld(1:npld);
     
     %keyboard
     figure
     dt=dtsva(i);
     subplot(2,2,1)
     plot([1:length(data)]*dt,data/max(data),'k'); hold on;
     plot(dt*t1(i)+[1:length(GF)]*dt,GF/max(GF),'r');
     %xlim([0,length(data)*dt])
     xlim([0 5]); ylim([-1.1 1.1]);
     xlabel('Time (s)')
     legend('Data','EGF');
     title([stasm(i,:),' ',compm(i,:)]);  
     
     subplot(2,2,2)
     plot([1:length(STF(i,:))]*dt,STF(i,:)); hold on;
     xlabel('Time (s)')
     title(['ASTF, moment:',num2str(sum(STF(i,:)),5)]);
     plot(t0(i)*dt,STF(round(t0(i))),'*')
     ylim([0 1.05*max(STF(i,:))])
     text(.1,.8*max(STF(i,:)),['ApprDur:',num2str(2*sqrt(t2(i)),2),' s'])
     xlim([0 2.1*t0(i)*dt]);
     %xlim([0,3*T1sv(i)])
     
     subplot(2,2,3)
     plot(tpld*dt,epld); hold on;
     xlabel('Time (s)');
     ylabel('Misfit');
     xlim([0 3*t0(i)*dt])
     [junk,ind]=min(abs(tpld-T));
     plot(tpld(ind)*dt,epld(ind),'*')
     ylim([0 1])
     
     subplot(2,2,4)
     plot([1:length(data)]*dt,data,'k')
     hold on
     plot([1:length(dhat)]*dt,dhat,'r')
     legend('Data','EGF*STF')
     title(['Seismogram Fit']);
     %xlim([0,length(data)*dt])
     xlim([0 5]);
     xlabel('Time (s)')
     
     % Decisions Time
     savei=menu('SAVE THIS RESULT','Yes P-wave','Yes S-wave', 'No REDO IT','No done');
     if(savei==1)
         DONE(i)=1;
         PhaseSv(i)='P';
         doi=0;
     elseif(savei==2);
         DONE(i)=1;
         PhaseSv(i)='S';
         doi=0;
     elseif(savei==3)
         DONE(i)=0;
         doi=1;
     elseif(savei==4)
         DONE(i)=0;
         doi=0;
     end
    elseif(ipick(i)==2)
     doi=0;
    end %ipick
    
 end; %while
 
 %%%% at the end of each station, save progress
 disp(['Done with ',stasm{i},' ',compm(i,:),' Saving to MEASUREMENTS.mat']);
 save('MEASUREMENTS.mat','DONE','Npts','t2','t1','t0','datasv','dtsv','dhatsv','GFsv',...
     'STF','STF_sm','Tsv','T1sv','epsv','epldsv','tpldsv');

end  % stations
disp('Done Making Measurements');


keyboard